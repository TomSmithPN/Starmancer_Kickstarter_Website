once you download the "github testing" file, launch it in any browser and see how's it doing. 
If you guys have any feedbacks that will be awesome
:D